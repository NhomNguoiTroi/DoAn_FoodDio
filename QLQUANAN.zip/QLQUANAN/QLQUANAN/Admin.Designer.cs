﻿namespace QLQUANAN
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpDoanhThu = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dtgvDoanhThu = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnDoanhThu = new System.Windows.Forms.Button();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.tpThucAn = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.nmFoodGia = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txbFoodTenMon = new System.Windows.Forms.TextBox();
            this.lbFoodTenMon = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txbFoodID = new System.Windows.Forms.TextBox();
            this.lbFoodID = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnFoodSua = new System.Windows.Forms.Button();
            this.bntFoodXoa = new System.Windows.Forms.Button();
            this.btnFoodThem = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txbFoodTim = new System.Windows.Forms.TextBox();
            this.btnFoodTim = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtgvThucAn = new System.Windows.Forms.DataGridView();
            this.tpKhoHang = new System.Windows.Forms.TabPage();
            this.panel18 = new System.Windows.Forms.Panel();
            this.dtgvKhoHang = new System.Windows.Forms.DataGridView();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.dtKhoNgayNhap = new System.Windows.Forms.DateTimePicker();
            this.lbKhoNgayNhap = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.nmKhoGiaNhap = new System.Windows.Forms.NumericUpDown();
            this.lbKhoGiaNhap = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txbKhoDVT = new System.Windows.Forms.TextBox();
            this.lbKhoDVT = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txbKhoSLT = new System.Windows.Forms.TextBox();
            this.lbKhoSoLuongTon = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lbKhotenNguyenLieu = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnKhoXem = new System.Windows.Forms.Button();
            this.btnKhoSua = new System.Windows.Forms.Button();
            this.btnKhoXoa = new System.Windows.Forms.Button();
            this.btnKhoThem = new System.Windows.Forms.Button();
            this.tpBanAn = new System.Windows.Forms.TabPage();
            this.panel27 = new System.Windows.Forms.Panel();
            this.dtgvBanAn = new System.Windows.Forms.DataGridView();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txbBanAnSoCho = new System.Windows.Forms.TextBox();
            this.lbBanAnSoCho = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txbBanAnTinhTrang = new System.Windows.Forms.TextBox();
            this.lbBanAnTinhTrang = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.txbBanAnTenBan = new System.Windows.Forms.TextBox();
            this.lbBanAnTenBan = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.TxbBanAnID = new System.Windows.Forms.TextBox();
            this.lbBanAnID = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.btnBanAnXem = new System.Windows.Forms.Button();
            this.btnBanAnSua = new System.Windows.Forms.Button();
            this.btnBanAnXoa = new System.Windows.Forms.Button();
            this.btnBanAnThem = new System.Windows.Forms.Button();
            this.tpTaiKhoan = new System.Windows.Forms.TabPage();
            this.panel34 = new System.Windows.Forms.Panel();
            this.dtgvTaiKhoan = new System.Windows.Forms.DataGridView();
            this.panel29 = new System.Windows.Forms.Panel();
            this.btnTaiKhoanDatLaiMK = new System.Windows.Forms.Button();
            this.panel31 = new System.Windows.Forms.Panel();
            this.txbTaiKhoanMatKhau = new System.Windows.Forms.TextBox();
            this.lbTaiKhoanMatKhau = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.txbTaiKhoanTenHienThi = new System.Windows.Forms.TextBox();
            this.lbTaiKhoanTenHienThi = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.txbTaiKhoanTenDangNhap = new System.Windows.Forms.TextBox();
            this.lbTaiKhoanTenDangNhap = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.btnTaiKhoanXem = new System.Windows.Forms.Button();
            this.btnTaiKhoanSua = new System.Windows.Forms.Button();
            this.btnTaiKhoanXoa = new System.Windows.Forms.Button();
            this.btnTaiKhoanThem = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbFoodHinhAnh = new System.Windows.Forms.Label();
            this.ptbFoodHinhAnh = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tpDoanhThu.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDoanhThu)).BeginInit();
            this.panel3.SuspendLayout();
            this.tpThucAn.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmFoodGia)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvThucAn)).BeginInit();
            this.tpKhoHang.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvKhoHang)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmKhoGiaNhap)).BeginInit();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tpBanAn.SuspendLayout();
            this.panel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBanAn)).BeginInit();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel21.SuspendLayout();
            this.tpTaiKhoan.SuspendLayout();
            this.panel34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaiKhoan)).BeginInit();
            this.panel29.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFoodHinhAnh)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpDoanhThu);
            this.tabControl1.Controls.Add(this.tpThucAn);
            this.tabControl1.Controls.Add(this.tpKhoHang);
            this.tabControl1.Controls.Add(this.tpBanAn);
            this.tabControl1.Controls.Add(this.tpTaiKhoan);
            this.tabControl1.Location = new System.Drawing.Point(2, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(801, 434);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tpDoanhThu
            // 
            this.tpDoanhThu.Controls.Add(this.panel4);
            this.tpDoanhThu.Controls.Add(this.panel3);
            this.tpDoanhThu.Location = new System.Drawing.Point(4, 25);
            this.tpDoanhThu.Name = "tpDoanhThu";
            this.tpDoanhThu.Padding = new System.Windows.Forms.Padding(3);
            this.tpDoanhThu.Size = new System.Drawing.Size(793, 405);
            this.tpDoanhThu.TabIndex = 0;
            this.tpDoanhThu.Text = "Doanh Thu";
            this.tpDoanhThu.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dtgvDoanhThu);
            this.panel4.Location = new System.Drawing.Point(3, 41);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(787, 361);
            this.panel4.TabIndex = 3;
            // 
            // dtgvDoanhThu
            // 
            this.dtgvDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDoanhThu.Location = new System.Drawing.Point(3, 6);
            this.dtgvDoanhThu.Name = "dtgvDoanhThu";
            this.dtgvDoanhThu.RowHeadersWidth = 51;
            this.dtgvDoanhThu.RowTemplate.Height = 24;
            this.dtgvDoanhThu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvDoanhThu.Size = new System.Drawing.Size(781, 355);
            this.dtgvDoanhThu.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnDoanhThu);
            this.panel3.Controls.Add(this.dtpTo);
            this.panel3.Controls.Add(this.dtpFrom);
            this.panel3.Location = new System.Drawing.Point(3, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(787, 32);
            this.panel3.TabIndex = 2;
            // 
            // btnDoanhThu
            // 
            this.btnDoanhThu.Location = new System.Drawing.Point(350, 3);
            this.btnDoanhThu.Name = "btnDoanhThu";
            this.btnDoanhThu.Size = new System.Drawing.Size(81, 26);
            this.btnDoanhThu.TabIndex = 2;
            this.btnDoanhThu.Text = "Thống kê";
            this.btnDoanhThu.UseVisualStyleBackColor = true;
            this.btnDoanhThu.Click += new System.EventHandler(this.btnDoanhThuThongKe_Click);
            // 
            // dtpTo
            // 
            this.dtpTo.Location = new System.Drawing.Point(584, 3);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(200, 22);
            this.dtpTo.TabIndex = 1;
            // 
            // dtpFrom
            // 
            this.dtpFrom.Location = new System.Drawing.Point(3, 3);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(200, 22);
            this.dtpFrom.TabIndex = 0;
            // 
            // tpThucAn
            // 
            this.tpThucAn.Controls.Add(this.panel6);
            this.tpThucAn.Controls.Add(this.panel5);
            this.tpThucAn.Controls.Add(this.panel2);
            this.tpThucAn.Controls.Add(this.panel1);
            this.tpThucAn.Location = new System.Drawing.Point(4, 25);
            this.tpThucAn.Name = "tpThucAn";
            this.tpThucAn.Padding = new System.Windows.Forms.Padding(3);
            this.tpThucAn.Size = new System.Drawing.Size(793, 405);
            this.tpThucAn.TabIndex = 1;
            this.tpThucAn.Text = "Thức Ăn";
            this.tpThucAn.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel10);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(435, 59);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(352, 343);
            this.panel6.TabIndex = 3;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.nmFoodGia);
            this.panel10.Controls.Add(this.label1);
            this.panel10.Location = new System.Drawing.Point(6, 109);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(344, 47);
            this.panel10.TabIndex = 3;
            // 
            // nmFoodGia
            // 
            this.nmFoodGia.Location = new System.Drawing.Point(101, 15);
            this.nmFoodGia.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.nmFoodGia.Name = "nmFoodGia";
            this.nmFoodGia.Size = new System.Drawing.Size(230, 22);
            this.nmFoodGia.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Giá:";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txbFoodTenMon);
            this.panel8.Controls.Add(this.lbFoodTenMon);
            this.panel8.Location = new System.Drawing.Point(5, 56);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(344, 47);
            this.panel8.TabIndex = 3;
            // 
            // txbFoodTenMon
            // 
            this.txbFoodTenMon.Location = new System.Drawing.Point(102, 14);
            this.txbFoodTenMon.Name = "txbFoodTenMon";
            this.txbFoodTenMon.Size = new System.Drawing.Size(230, 22);
            this.txbFoodTenMon.TabIndex = 1;
            // 
            // lbFoodTenMon
            // 
            this.lbFoodTenMon.AutoSize = true;
            this.lbFoodTenMon.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFoodTenMon.Location = new System.Drawing.Point(3, 11);
            this.lbFoodTenMon.Name = "lbFoodTenMon";
            this.lbFoodTenMon.Size = new System.Drawing.Size(83, 24);
            this.lbFoodTenMon.TabIndex = 0;
            this.lbFoodTenMon.Text = "Tên món:";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txbFoodID);
            this.panel7.Controls.Add(this.lbFoodID);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(344, 47);
            this.panel7.TabIndex = 2;
            // 
            // txbFoodID
            // 
            this.txbFoodID.Location = new System.Drawing.Point(104, 14);
            this.txbFoodID.Name = "txbFoodID";
            this.txbFoodID.Size = new System.Drawing.Size(228, 22);
            this.txbFoodID.TabIndex = 1;
            // 
            // lbFoodID
            // 
            this.lbFoodID.AutoSize = true;
            this.lbFoodID.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFoodID.Location = new System.Drawing.Point(3, 11);
            this.lbFoodID.Name = "lbFoodID";
            this.lbFoodID.Size = new System.Drawing.Size(31, 24);
            this.lbFoodID.TabIndex = 0;
            this.lbFoodID.Text = "ID:";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnFoodSua);
            this.panel5.Controls.Add(this.bntFoodXoa);
            this.panel5.Controls.Add(this.btnFoodThem);
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(426, 50);
            this.panel5.TabIndex = 2;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // btnFoodSua
            // 
            this.btnFoodSua.Location = new System.Drawing.Point(305, 3);
            this.btnFoodSua.Name = "btnFoodSua";
            this.btnFoodSua.Size = new System.Drawing.Size(95, 44);
            this.btnFoodSua.TabIndex = 2;
            this.btnFoodSua.Text = "Sửa";
            this.btnFoodSua.UseVisualStyleBackColor = true;
            // 
            // bntFoodXoa
            // 
            this.bntFoodXoa.Location = new System.Drawing.Point(158, 3);
            this.bntFoodXoa.Name = "bntFoodXoa";
            this.bntFoodXoa.Size = new System.Drawing.Size(95, 44);
            this.bntFoodXoa.TabIndex = 1;
            this.bntFoodXoa.Text = "Xóa";
            this.bntFoodXoa.UseVisualStyleBackColor = true;
            this.bntFoodXoa.Click += new System.EventHandler(this.bntFoodXoa_Click);
            // 
            // btnFoodThem
            // 
            this.btnFoodThem.Location = new System.Drawing.Point(3, 3);
            this.btnFoodThem.Name = "btnFoodThem";
            this.btnFoodThem.Size = new System.Drawing.Size(95, 44);
            this.btnFoodThem.TabIndex = 0;
            this.btnFoodThem.Text = "Thêm";
            this.btnFoodThem.UseVisualStyleBackColor = true;
            this.btnFoodThem.Click += new System.EventHandler(this.btnFoodThem_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txbFoodTim);
            this.panel2.Controls.Add(this.btnFoodTim);
            this.panel2.Location = new System.Drawing.Point(435, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(350, 50);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // txbFoodTim
            // 
            this.txbFoodTim.Location = new System.Drawing.Point(14, 14);
            this.txbFoodTim.Name = "txbFoodTim";
            this.txbFoodTim.Size = new System.Drawing.Size(232, 22);
            this.txbFoodTim.TabIndex = 5;
            // 
            // btnFoodTim
            // 
            this.btnFoodTim.Location = new System.Drawing.Point(252, 3);
            this.btnFoodTim.Name = "btnFoodTim";
            this.btnFoodTim.Size = new System.Drawing.Size(95, 44);
            this.btnFoodTim.TabIndex = 4;
            this.btnFoodTim.Text = "Tìm";
            this.btnFoodTim.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dtgvThucAn);
            this.panel1.Location = new System.Drawing.Point(3, 59);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(426, 343);
            this.panel1.TabIndex = 0;
            // 
            // dtgvThucAn
            // 
            this.dtgvThucAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvThucAn.Location = new System.Drawing.Point(3, 3);
            this.dtgvThucAn.Name = "dtgvThucAn";
            this.dtgvThucAn.RowHeadersWidth = 51;
            this.dtgvThucAn.RowTemplate.Height = 24;
            this.dtgvThucAn.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvThucAn.Size = new System.Drawing.Size(420, 334);
            this.dtgvThucAn.TabIndex = 0;
            this.dtgvThucAn.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvThucAn_CellClick);
            // 
            // tpKhoHang
            // 
            this.tpKhoHang.Controls.Add(this.panel18);
            this.tpKhoHang.Controls.Add(this.panel13);
            this.tpKhoHang.Controls.Add(this.panel12);
            this.tpKhoHang.Controls.Add(this.panel11);
            this.tpKhoHang.Location = new System.Drawing.Point(4, 25);
            this.tpKhoHang.Name = "tpKhoHang";
            this.tpKhoHang.Padding = new System.Windows.Forms.Padding(3);
            this.tpKhoHang.Size = new System.Drawing.Size(793, 405);
            this.tpKhoHang.TabIndex = 2;
            this.tpKhoHang.Text = "Kho Hàng";
            this.tpKhoHang.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.dtgvKhoHang);
            this.panel18.Location = new System.Drawing.Point(8, 56);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(426, 346);
            this.panel18.TabIndex = 6;
            // 
            // dtgvKhoHang
            // 
            this.dtgvKhoHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvKhoHang.Location = new System.Drawing.Point(0, 0);
            this.dtgvKhoHang.Name = "dtgvKhoHang";
            this.dtgvKhoHang.RowHeadersWidth = 51;
            this.dtgvKhoHang.RowTemplate.Height = 24;
            this.dtgvKhoHang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvKhoHang.Size = new System.Drawing.Size(423, 340);
            this.dtgvKhoHang.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel20);
            this.panel13.Controls.Add(this.panel19);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Controls.Add(this.panel15);
            this.panel13.Controls.Add(this.panel16);
            this.panel13.Controls.Add(this.panel17);
            this.panel13.Location = new System.Drawing.Point(438, 56);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(352, 346);
            this.panel13.TabIndex = 5;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.dtKhoNgayNhap);
            this.panel20.Controls.Add(this.lbKhoNgayNhap);
            this.panel20.Location = new System.Drawing.Point(2, 268);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(344, 47);
            this.panel20.TabIndex = 4;
            // 
            // dtKhoNgayNhap
            // 
            this.dtKhoNgayNhap.Location = new System.Drawing.Point(151, 13);
            this.dtKhoNgayNhap.Name = "dtKhoNgayNhap";
            this.dtKhoNgayNhap.Size = new System.Drawing.Size(184, 22);
            this.dtKhoNgayNhap.TabIndex = 1;
            // 
            // lbKhoNgayNhap
            // 
            this.lbKhoNgayNhap.AutoSize = true;
            this.lbKhoNgayNhap.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKhoNgayNhap.Location = new System.Drawing.Point(3, 11);
            this.lbKhoNgayNhap.Name = "lbKhoNgayNhap";
            this.lbKhoNgayNhap.Size = new System.Drawing.Size(99, 24);
            this.lbKhoNgayNhap.TabIndex = 0;
            this.lbKhoNgayNhap.Text = "Ngày nhập:";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.nmKhoGiaNhap);
            this.panel19.Controls.Add(this.lbKhoGiaNhap);
            this.panel19.Location = new System.Drawing.Point(2, 215);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(344, 47);
            this.panel19.TabIndex = 4;
            // 
            // nmKhoGiaNhap
            // 
            this.nmKhoGiaNhap.Location = new System.Drawing.Point(151, 15);
            this.nmKhoGiaNhap.Name = "nmKhoGiaNhap";
            this.nmKhoGiaNhap.Size = new System.Drawing.Size(184, 22);
            this.nmKhoGiaNhap.TabIndex = 1;
            // 
            // lbKhoGiaNhap
            // 
            this.lbKhoGiaNhap.AutoSize = true;
            this.lbKhoGiaNhap.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKhoGiaNhap.Location = new System.Drawing.Point(3, 11);
            this.lbKhoGiaNhap.Name = "lbKhoGiaNhap";
            this.lbKhoGiaNhap.Size = new System.Drawing.Size(85, 24);
            this.lbKhoGiaNhap.TabIndex = 0;
            this.lbKhoGiaNhap.Text = "Giá nhập:";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.txbKhoDVT);
            this.panel14.Controls.Add(this.lbKhoDVT);
            this.panel14.Location = new System.Drawing.Point(3, 162);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(344, 47);
            this.panel14.TabIndex = 4;
            // 
            // txbKhoDVT
            // 
            this.txbKhoDVT.Location = new System.Drawing.Point(150, 13);
            this.txbKhoDVT.Name = "txbKhoDVT";
            this.txbKhoDVT.Size = new System.Drawing.Size(182, 22);
            this.txbKhoDVT.TabIndex = 2;
            // 
            // lbKhoDVT
            // 
            this.lbKhoDVT.AutoSize = true;
            this.lbKhoDVT.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKhoDVT.Location = new System.Drawing.Point(3, 11);
            this.lbKhoDVT.Name = "lbKhoDVT";
            this.lbKhoDVT.Size = new System.Drawing.Size(99, 24);
            this.lbKhoDVT.TabIndex = 0;
            this.lbKhoDVT.Text = "Đơn vị tính:";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.txbKhoSLT);
            this.panel15.Controls.Add(this.lbKhoSoLuongTon);
            this.panel15.Location = new System.Drawing.Point(5, 109);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(344, 47);
            this.panel15.TabIndex = 3;
            this.panel15.Paint += new System.Windows.Forms.PaintEventHandler(this.panel15_Paint);
            // 
            // txbKhoSLT
            // 
            this.txbKhoSLT.Location = new System.Drawing.Point(148, 13);
            this.txbKhoSLT.Name = "txbKhoSLT";
            this.txbKhoSLT.Size = new System.Drawing.Size(184, 22);
            this.txbKhoSLT.TabIndex = 2;
            // 
            // lbKhoSoLuongTon
            // 
            this.lbKhoSoLuongTon.AutoSize = true;
            this.lbKhoSoLuongTon.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKhoSoLuongTon.Location = new System.Drawing.Point(3, 11);
            this.lbKhoSoLuongTon.Name = "lbKhoSoLuongTon";
            this.lbKhoSoLuongTon.Size = new System.Drawing.Size(114, 24);
            this.lbKhoSoLuongTon.TabIndex = 0;
            this.lbKhoSoLuongTon.Text = "Số lượng tồn:";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.textBox2);
            this.panel16.Controls.Add(this.lbKhotenNguyenLieu);
            this.panel16.Location = new System.Drawing.Point(5, 56);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(344, 47);
            this.panel16.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(148, 14);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(184, 22);
            this.textBox2.TabIndex = 1;
            // 
            // lbKhotenNguyenLieu
            // 
            this.lbKhotenNguyenLieu.AutoSize = true;
            this.lbKhotenNguyenLieu.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKhotenNguyenLieu.Location = new System.Drawing.Point(3, 11);
            this.lbKhotenNguyenLieu.Name = "lbKhotenNguyenLieu";
            this.lbKhotenNguyenLieu.Size = new System.Drawing.Size(139, 24);
            this.lbKhotenNguyenLieu.TabIndex = 0;
            this.lbKhotenNguyenLieu.Text = "Tên nguyên liệu:";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.textBox3);
            this.panel17.Controls.Add(this.label5);
            this.panel17.Location = new System.Drawing.Point(3, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(344, 47);
            this.panel17.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(150, 14);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(182, 22);
            this.textBox3.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "ID:";
            // 
            // panel12
            // 
            this.panel12.Location = new System.Drawing.Point(440, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(350, 50);
            this.panel12.TabIndex = 4;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.btnKhoXem);
            this.panel11.Controls.Add(this.btnKhoSua);
            this.panel11.Controls.Add(this.btnKhoXoa);
            this.panel11.Controls.Add(this.btnKhoThem);
            this.panel11.Location = new System.Drawing.Point(8, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(426, 50);
            this.panel11.TabIndex = 3;
            // 
            // btnKhoXem
            // 
            this.btnKhoXem.Location = new System.Drawing.Point(303, 3);
            this.btnKhoXem.Name = "btnKhoXem";
            this.btnKhoXem.Size = new System.Drawing.Size(95, 44);
            this.btnKhoXem.TabIndex = 3;
            this.btnKhoXem.Text = "Xem";
            this.btnKhoXem.UseVisualStyleBackColor = true;
            // 
            // btnKhoSua
            // 
            this.btnKhoSua.Location = new System.Drawing.Point(202, 3);
            this.btnKhoSua.Name = "btnKhoSua";
            this.btnKhoSua.Size = new System.Drawing.Size(95, 44);
            this.btnKhoSua.TabIndex = 2;
            this.btnKhoSua.Text = "Sửa";
            this.btnKhoSua.UseVisualStyleBackColor = true;
            // 
            // btnKhoXoa
            // 
            this.btnKhoXoa.Location = new System.Drawing.Point(101, 3);
            this.btnKhoXoa.Name = "btnKhoXoa";
            this.btnKhoXoa.Size = new System.Drawing.Size(95, 44);
            this.btnKhoXoa.TabIndex = 1;
            this.btnKhoXoa.Text = "Xóa";
            this.btnKhoXoa.UseVisualStyleBackColor = true;
            // 
            // btnKhoThem
            // 
            this.btnKhoThem.Location = new System.Drawing.Point(0, 3);
            this.btnKhoThem.Name = "btnKhoThem";
            this.btnKhoThem.Size = new System.Drawing.Size(95, 44);
            this.btnKhoThem.TabIndex = 0;
            this.btnKhoThem.Text = "Thêm";
            this.btnKhoThem.UseVisualStyleBackColor = true;
            // 
            // tpBanAn
            // 
            this.tpBanAn.Controls.Add(this.panel27);
            this.tpBanAn.Controls.Add(this.panel22);
            this.tpBanAn.Controls.Add(this.panel21);
            this.tpBanAn.Location = new System.Drawing.Point(4, 25);
            this.tpBanAn.Name = "tpBanAn";
            this.tpBanAn.Padding = new System.Windows.Forms.Padding(3);
            this.tpBanAn.Size = new System.Drawing.Size(793, 405);
            this.tpBanAn.TabIndex = 3;
            this.tpBanAn.Text = "Bàn Ăn";
            this.tpBanAn.UseVisualStyleBackColor = true;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.dtgvBanAn);
            this.panel27.Location = new System.Drawing.Point(6, 59);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(427, 340);
            this.panel27.TabIndex = 6;
            // 
            // dtgvBanAn
            // 
            this.dtgvBanAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvBanAn.Location = new System.Drawing.Point(3, 3);
            this.dtgvBanAn.Name = "dtgvBanAn";
            this.dtgvBanAn.RowHeadersWidth = 51;
            this.dtgvBanAn.RowTemplate.Height = 24;
            this.dtgvBanAn.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvBanAn.Size = new System.Drawing.Size(421, 334);
            this.dtgvBanAn.TabIndex = 0;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.panel23);
            this.panel22.Controls.Add(this.panel24);
            this.panel22.Controls.Add(this.panel25);
            this.panel22.Controls.Add(this.panel26);
            this.panel22.Location = new System.Drawing.Point(433, 56);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(352, 343);
            this.panel22.TabIndex = 5;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.txbBanAnSoCho);
            this.panel23.Controls.Add(this.lbBanAnSoCho);
            this.panel23.Location = new System.Drawing.Point(6, 162);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(344, 47);
            this.panel23.TabIndex = 3;
            // 
            // txbBanAnSoCho
            // 
            this.txbBanAnSoCho.Location = new System.Drawing.Point(101, 14);
            this.txbBanAnSoCho.Name = "txbBanAnSoCho";
            this.txbBanAnSoCho.Size = new System.Drawing.Size(230, 22);
            this.txbBanAnSoCho.TabIndex = 3;
            // 
            // lbBanAnSoCho
            // 
            this.lbBanAnSoCho.AutoSize = true;
            this.lbBanAnSoCho.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBanAnSoCho.Location = new System.Drawing.Point(3, 11);
            this.lbBanAnSoCho.Name = "lbBanAnSoCho";
            this.lbBanAnSoCho.Size = new System.Drawing.Size(70, 24);
            this.lbBanAnSoCho.TabIndex = 0;
            this.lbBanAnSoCho.Text = "Số chỗ:";
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.txbBanAnTinhTrang);
            this.panel24.Controls.Add(this.lbBanAnTinhTrang);
            this.panel24.Location = new System.Drawing.Point(5, 109);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(344, 47);
            this.panel24.TabIndex = 3;
            // 
            // txbBanAnTinhTrang
            // 
            this.txbBanAnTinhTrang.Location = new System.Drawing.Point(102, 14);
            this.txbBanAnTinhTrang.Name = "txbBanAnTinhTrang";
            this.txbBanAnTinhTrang.Size = new System.Drawing.Size(230, 22);
            this.txbBanAnTinhTrang.TabIndex = 2;
            // 
            // lbBanAnTinhTrang
            // 
            this.lbBanAnTinhTrang.AutoSize = true;
            this.lbBanAnTinhTrang.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBanAnTinhTrang.Location = new System.Drawing.Point(3, 11);
            this.lbBanAnTinhTrang.Name = "lbBanAnTinhTrang";
            this.lbBanAnTinhTrang.Size = new System.Drawing.Size(94, 24);
            this.lbBanAnTinhTrang.TabIndex = 0;
            this.lbBanAnTinhTrang.Text = "Tình trạng:";
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.txbBanAnTenBan);
            this.panel25.Controls.Add(this.lbBanAnTenBan);
            this.panel25.Location = new System.Drawing.Point(5, 56);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(344, 47);
            this.panel25.TabIndex = 3;
            // 
            // txbBanAnTenBan
            // 
            this.txbBanAnTenBan.Location = new System.Drawing.Point(102, 14);
            this.txbBanAnTenBan.Name = "txbBanAnTenBan";
            this.txbBanAnTenBan.Size = new System.Drawing.Size(230, 22);
            this.txbBanAnTenBan.TabIndex = 1;
            // 
            // lbBanAnTenBan
            // 
            this.lbBanAnTenBan.AutoSize = true;
            this.lbBanAnTenBan.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBanAnTenBan.Location = new System.Drawing.Point(3, 11);
            this.lbBanAnTenBan.Name = "lbBanAnTenBan";
            this.lbBanAnTenBan.Size = new System.Drawing.Size(78, 24);
            this.lbBanAnTenBan.TabIndex = 0;
            this.lbBanAnTenBan.Text = "Tên bàn:";
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.TxbBanAnID);
            this.panel26.Controls.Add(this.lbBanAnID);
            this.panel26.Location = new System.Drawing.Point(3, 3);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(344, 47);
            this.panel26.TabIndex = 2;
            // 
            // TxbBanAnID
            // 
            this.TxbBanAnID.Location = new System.Drawing.Point(104, 14);
            this.TxbBanAnID.Name = "TxbBanAnID";
            this.TxbBanAnID.Size = new System.Drawing.Size(228, 22);
            this.TxbBanAnID.TabIndex = 1;
            // 
            // lbBanAnID
            // 
            this.lbBanAnID.AutoSize = true;
            this.lbBanAnID.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBanAnID.Location = new System.Drawing.Point(3, 11);
            this.lbBanAnID.Name = "lbBanAnID";
            this.lbBanAnID.Size = new System.Drawing.Size(31, 24);
            this.lbBanAnID.TabIndex = 0;
            this.lbBanAnID.Text = "ID:";
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.btnBanAnXem);
            this.panel21.Controls.Add(this.btnBanAnSua);
            this.panel21.Controls.Add(this.btnBanAnXoa);
            this.panel21.Controls.Add(this.btnBanAnThem);
            this.panel21.Location = new System.Drawing.Point(6, 6);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(426, 50);
            this.panel21.TabIndex = 4;
            // 
            // btnBanAnXem
            // 
            this.btnBanAnXem.Location = new System.Drawing.Point(303, 3);
            this.btnBanAnXem.Name = "btnBanAnXem";
            this.btnBanAnXem.Size = new System.Drawing.Size(95, 44);
            this.btnBanAnXem.TabIndex = 3;
            this.btnBanAnXem.Text = "Xem";
            this.btnBanAnXem.UseVisualStyleBackColor = true;
            // 
            // btnBanAnSua
            // 
            this.btnBanAnSua.Location = new System.Drawing.Point(202, 3);
            this.btnBanAnSua.Name = "btnBanAnSua";
            this.btnBanAnSua.Size = new System.Drawing.Size(95, 44);
            this.btnBanAnSua.TabIndex = 2;
            this.btnBanAnSua.Text = "Sửa";
            this.btnBanAnSua.UseVisualStyleBackColor = true;
            // 
            // btnBanAnXoa
            // 
            this.btnBanAnXoa.Location = new System.Drawing.Point(101, 3);
            this.btnBanAnXoa.Name = "btnBanAnXoa";
            this.btnBanAnXoa.Size = new System.Drawing.Size(95, 44);
            this.btnBanAnXoa.TabIndex = 1;
            this.btnBanAnXoa.Text = "Xóa";
            this.btnBanAnXoa.UseVisualStyleBackColor = true;
            // 
            // btnBanAnThem
            // 
            this.btnBanAnThem.Location = new System.Drawing.Point(0, 3);
            this.btnBanAnThem.Name = "btnBanAnThem";
            this.btnBanAnThem.Size = new System.Drawing.Size(95, 44);
            this.btnBanAnThem.TabIndex = 0;
            this.btnBanAnThem.Text = "Thêm";
            this.btnBanAnThem.UseVisualStyleBackColor = true;
            // 
            // tpTaiKhoan
            // 
            this.tpTaiKhoan.Controls.Add(this.panel34);
            this.tpTaiKhoan.Controls.Add(this.panel29);
            this.tpTaiKhoan.Controls.Add(this.panel28);
            this.tpTaiKhoan.Location = new System.Drawing.Point(4, 25);
            this.tpTaiKhoan.Name = "tpTaiKhoan";
            this.tpTaiKhoan.Padding = new System.Windows.Forms.Padding(3);
            this.tpTaiKhoan.Size = new System.Drawing.Size(793, 405);
            this.tpTaiKhoan.TabIndex = 4;
            this.tpTaiKhoan.Text = "Tài Khoản";
            this.tpTaiKhoan.UseVisualStyleBackColor = true;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.dtgvTaiKhoan);
            this.panel34.Location = new System.Drawing.Point(6, 59);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(423, 337);
            this.panel34.TabIndex = 7;
            // 
            // dtgvTaiKhoan
            // 
            this.dtgvTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvTaiKhoan.Location = new System.Drawing.Point(3, 3);
            this.dtgvTaiKhoan.Name = "dtgvTaiKhoan";
            this.dtgvTaiKhoan.RowHeadersWidth = 51;
            this.dtgvTaiKhoan.RowTemplate.Height = 24;
            this.dtgvTaiKhoan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvTaiKhoan.Size = new System.Drawing.Size(417, 331);
            this.dtgvTaiKhoan.TabIndex = 0;
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.btnTaiKhoanDatLaiMK);
            this.panel29.Controls.Add(this.panel31);
            this.panel29.Controls.Add(this.panel32);
            this.panel29.Controls.Add(this.panel33);
            this.panel29.Location = new System.Drawing.Point(435, 59);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(352, 343);
            this.panel29.TabIndex = 6;
            // 
            // btnTaiKhoanDatLaiMK
            // 
            this.btnTaiKhoanDatLaiMK.Location = new System.Drawing.Point(251, 162);
            this.btnTaiKhoanDatLaiMK.Name = "btnTaiKhoanDatLaiMK";
            this.btnTaiKhoanDatLaiMK.Size = new System.Drawing.Size(84, 47);
            this.btnTaiKhoanDatLaiMK.TabIndex = 4;
            this.btnTaiKhoanDatLaiMK.Text = "Đặt lại mật khẩu";
            this.btnTaiKhoanDatLaiMK.UseVisualStyleBackColor = true;
            this.btnTaiKhoanDatLaiMK.Click += new System.EventHandler(this.btnTaiKhoanDatLaiMK_Click);
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.txbTaiKhoanMatKhau);
            this.panel31.Controls.Add(this.lbTaiKhoanMatKhau);
            this.panel31.Location = new System.Drawing.Point(5, 109);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(344, 47);
            this.panel31.TabIndex = 3;
            // 
            // txbTaiKhoanMatKhau
            // 
            this.txbTaiKhoanMatKhau.Location = new System.Drawing.Point(139, 14);
            this.txbTaiKhoanMatKhau.Name = "txbTaiKhoanMatKhau";
            this.txbTaiKhoanMatKhau.Size = new System.Drawing.Size(193, 22);
            this.txbTaiKhoanMatKhau.TabIndex = 2;
            this.txbTaiKhoanMatKhau.UseSystemPasswordChar = true;
            // 
            // lbTaiKhoanMatKhau
            // 
            this.lbTaiKhoanMatKhau.AutoSize = true;
            this.lbTaiKhoanMatKhau.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTaiKhoanMatKhau.Location = new System.Drawing.Point(3, 11);
            this.lbTaiKhoanMatKhau.Name = "lbTaiKhoanMatKhau";
            this.lbTaiKhoanMatKhau.Size = new System.Drawing.Size(86, 24);
            this.lbTaiKhoanMatKhau.TabIndex = 0;
            this.lbTaiKhoanMatKhau.Text = "Mật khẩu:";
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.txbTaiKhoanTenHienThi);
            this.panel32.Controls.Add(this.lbTaiKhoanTenHienThi);
            this.panel32.Location = new System.Drawing.Point(5, 56);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(344, 47);
            this.panel32.TabIndex = 3;
            // 
            // txbTaiKhoanTenHienThi
            // 
            this.txbTaiKhoanTenHienThi.Location = new System.Drawing.Point(139, 14);
            this.txbTaiKhoanTenHienThi.Name = "txbTaiKhoanTenHienThi";
            this.txbTaiKhoanTenHienThi.Size = new System.Drawing.Size(193, 22);
            this.txbTaiKhoanTenHienThi.TabIndex = 1;
            // 
            // lbTaiKhoanTenHienThi
            // 
            this.lbTaiKhoanTenHienThi.AutoSize = true;
            this.lbTaiKhoanTenHienThi.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTaiKhoanTenHienThi.Location = new System.Drawing.Point(3, 11);
            this.lbTaiKhoanTenHienThi.Name = "lbTaiKhoanTenHienThi";
            this.lbTaiKhoanTenHienThi.Size = new System.Drawing.Size(106, 24);
            this.lbTaiKhoanTenHienThi.TabIndex = 0;
            this.lbTaiKhoanTenHienThi.Text = "Tên hiển thị:";
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.txbTaiKhoanTenDangNhap);
            this.panel33.Controls.Add(this.lbTaiKhoanTenDangNhap);
            this.panel33.Location = new System.Drawing.Point(3, 3);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(344, 47);
            this.panel33.TabIndex = 2;
            // 
            // txbTaiKhoanTenDangNhap
            // 
            this.txbTaiKhoanTenDangNhap.Location = new System.Drawing.Point(141, 14);
            this.txbTaiKhoanTenDangNhap.Name = "txbTaiKhoanTenDangNhap";
            this.txbTaiKhoanTenDangNhap.Size = new System.Drawing.Size(191, 22);
            this.txbTaiKhoanTenDangNhap.TabIndex = 1;
            // 
            // lbTaiKhoanTenDangNhap
            // 
            this.lbTaiKhoanTenDangNhap.AutoSize = true;
            this.lbTaiKhoanTenDangNhap.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTaiKhoanTenDangNhap.Location = new System.Drawing.Point(3, 11);
            this.lbTaiKhoanTenDangNhap.Name = "lbTaiKhoanTenDangNhap";
            this.lbTaiKhoanTenDangNhap.Size = new System.Drawing.Size(132, 24);
            this.lbTaiKhoanTenDangNhap.TabIndex = 0;
            this.lbTaiKhoanTenDangNhap.Text = "Tên đăng nhập:";
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.btnTaiKhoanXem);
            this.panel28.Controls.Add(this.btnTaiKhoanSua);
            this.panel28.Controls.Add(this.btnTaiKhoanXoa);
            this.panel28.Controls.Add(this.btnTaiKhoanThem);
            this.panel28.Location = new System.Drawing.Point(3, 3);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(426, 50);
            this.panel28.TabIndex = 5;
            // 
            // btnTaiKhoanXem
            // 
            this.btnTaiKhoanXem.Location = new System.Drawing.Point(303, 3);
            this.btnTaiKhoanXem.Name = "btnTaiKhoanXem";
            this.btnTaiKhoanXem.Size = new System.Drawing.Size(95, 44);
            this.btnTaiKhoanXem.TabIndex = 3;
            this.btnTaiKhoanXem.Text = "Xem";
            this.btnTaiKhoanXem.UseVisualStyleBackColor = true;
            // 
            // btnTaiKhoanSua
            // 
            this.btnTaiKhoanSua.Location = new System.Drawing.Point(202, 3);
            this.btnTaiKhoanSua.Name = "btnTaiKhoanSua";
            this.btnTaiKhoanSua.Size = new System.Drawing.Size(95, 44);
            this.btnTaiKhoanSua.TabIndex = 2;
            this.btnTaiKhoanSua.Text = "Sửa";
            this.btnTaiKhoanSua.UseVisualStyleBackColor = true;
            // 
            // btnTaiKhoanXoa
            // 
            this.btnTaiKhoanXoa.Location = new System.Drawing.Point(101, 3);
            this.btnTaiKhoanXoa.Name = "btnTaiKhoanXoa";
            this.btnTaiKhoanXoa.Size = new System.Drawing.Size(95, 44);
            this.btnTaiKhoanXoa.TabIndex = 1;
            this.btnTaiKhoanXoa.Text = "Xóa";
            this.btnTaiKhoanXoa.UseVisualStyleBackColor = true;
            // 
            // btnTaiKhoanThem
            // 
            this.btnTaiKhoanThem.Location = new System.Drawing.Point(0, 3);
            this.btnTaiKhoanThem.Name = "btnTaiKhoanThem";
            this.btnTaiKhoanThem.Size = new System.Drawing.Size(95, 44);
            this.btnTaiKhoanThem.TabIndex = 0;
            this.btnTaiKhoanThem.Text = "Thêm";
            this.btnTaiKhoanThem.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.ptbFoodHinhAnh);
            this.panel9.Controls.Add(this.lbFoodHinhAnh);
            this.panel9.Location = new System.Drawing.Point(6, 162);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(346, 175);
            this.panel9.TabIndex = 4;
            // 
            // lbFoodHinhAnh
            // 
            this.lbFoodHinhAnh.AutoSize = true;
            this.lbFoodHinhAnh.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFoodHinhAnh.Location = new System.Drawing.Point(3, 11);
            this.lbFoodHinhAnh.Name = "lbFoodHinhAnh";
            this.lbFoodHinhAnh.Size = new System.Drawing.Size(86, 24);
            this.lbFoodHinhAnh.TabIndex = 0;
            this.lbFoodHinhAnh.Text = "Hình Ảnh:";
            // 
            // ptbFoodHinhAnh
            // 
            this.ptbFoodHinhAnh.Location = new System.Drawing.Point(109, 3);
            this.ptbFoodHinhAnh.Name = "ptbFoodHinhAnh";
            this.ptbFoodHinhAnh.Size = new System.Drawing.Size(220, 158);
            this.ptbFoodHinhAnh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFoodHinhAnh.TabIndex = 1;
            this.ptbFoodHinhAnh.TabStop = false;
            this.ptbFoodHinhAnh.Click += new System.EventHandler(this.ptbFoodHinhAnh_Click);
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 438);
            this.Controls.Add(this.tabControl1);
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.fAdmin_Load);
            this.tabControl1.ResumeLayout(false);
            this.tpDoanhThu.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDoanhThu)).EndInit();
            this.panel3.ResumeLayout(false);
            this.tpThucAn.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmFoodGia)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvThucAn)).EndInit();
            this.tpKhoHang.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvKhoHang)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmKhoGiaNhap)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.tpBanAn.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBanAn)).EndInit();
            this.panel22.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.tpTaiKhoan.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaiKhoan)).EndInit();
            this.panel29.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFoodHinhAnh)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpDoanhThu;
        private System.Windows.Forms.TabPage tpThucAn;
        private System.Windows.Forms.TabPage tpKhoHang;
        private System.Windows.Forms.TabPage tpBanAn;
        private System.Windows.Forms.TabPage tpTaiKhoan;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dtgvDoanhThu;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnDoanhThu;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txbFoodTim;
        private System.Windows.Forms.Button btnFoodSua;
        private System.Windows.Forms.Button bntFoodXoa;
        private System.Windows.Forms.Button btnFoodThem;
        private System.Windows.Forms.Button btnFoodTim;
        private System.Windows.Forms.DataGridView dtgvThucAn;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txbFoodTenMon;
        private System.Windows.Forms.Label lbFoodTenMon;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txbFoodID;
        private System.Windows.Forms.Label lbFoodID;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.NumericUpDown nmFoodGia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button btnKhoXem;
        private System.Windows.Forms.Button btnKhoSua;
        private System.Windows.Forms.Button btnKhoXoa;
        private System.Windows.Forms.Button btnKhoThem;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.DataGridView dtgvKhoHang;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label lbKhoSoLuongTon;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lbKhotenNguyenLieu;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbKhoSLT;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.DateTimePicker dtKhoNgayNhap;
        private System.Windows.Forms.Label lbKhoNgayNhap;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.NumericUpDown nmKhoGiaNhap;
        private System.Windows.Forms.Label lbKhoGiaNhap;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txbKhoDVT;
        private System.Windows.Forms.Label lbKhoDVT;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button btnBanAnXem;
        private System.Windows.Forms.Button btnBanAnSua;
        private System.Windows.Forms.Button btnBanAnXoa;
        private System.Windows.Forms.Button btnBanAnThem;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.DataGridView dtgvBanAn;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label lbBanAnSoCho;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label lbBanAnTinhTrang;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox txbBanAnTenBan;
        private System.Windows.Forms.Label lbBanAnTenBan;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TextBox TxbBanAnID;
        private System.Windows.Forms.Label lbBanAnID;
        private System.Windows.Forms.TextBox txbBanAnTinhTrang;
        private System.Windows.Forms.TextBox txbBanAnSoCho;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.DataGridView dtgvTaiKhoan;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Button btnTaiKhoanDatLaiMK;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox txbTaiKhoanMatKhau;
        private System.Windows.Forms.Label lbTaiKhoanMatKhau;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TextBox txbTaiKhoanTenHienThi;
        private System.Windows.Forms.Label lbTaiKhoanTenHienThi;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.TextBox txbTaiKhoanTenDangNhap;
        private System.Windows.Forms.Label lbTaiKhoanTenDangNhap;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Button btnTaiKhoanXem;
        private System.Windows.Forms.Button btnTaiKhoanSua;
        private System.Windows.Forms.Button btnTaiKhoanXoa;
        private System.Windows.Forms.Button btnTaiKhoanThem;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.PictureBox ptbFoodHinhAnh;
        private System.Windows.Forms.Label lbFoodHinhAnh;
    }
}