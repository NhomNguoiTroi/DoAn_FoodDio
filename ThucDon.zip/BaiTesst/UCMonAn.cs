﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiTesst
{
    public partial class UCMonAn : UserControl
    {
        public UCMonAn()
        {
            InitializeComponent();
        }
        public string TenMon
        {
            get { return lblTenMon.Text; }
            set { lblTenMon.Text = value; }
        }
        public string GiaMon
        {
            get { return lblGia.Text; }
            set { lblGia.Text = value; }
        }
        public Image HinhAnh
        {
            get { return picHinhAnh.Image; }
            set { picHinhAnh.Image = value; }
        }
    }
}
