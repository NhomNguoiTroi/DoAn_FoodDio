﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiTesst
{
    public partial class fThucDon : Form
    {
        public fThucDon()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           /* List<UCMonAn> monAns = new List<UCMonAn>();
            for (int i = 1; i <= 12; i++)
            {
                UCMonAn monAn = new UCMonAn();
                monAn.TenMon = "Món Ăn " + i;
                monAn.GiaMon = (10000).ToString()+(i*5000) + " VND";
                monAn.HinhAnh = Image.FromFile("D:\\Downloads\\monan"+i+".jpg"); // Thay đổi đường dẫn hình ảnh phù hợp
                monAns.Add(monAn);
            }
            foreach (var monAn in monAns)
            {
                flowLayoutPanel1.Controls.Add(monAn);
            }*/
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ucMonAn2_Load(object sender, EventArgs e)
        {

        }
    }
}
