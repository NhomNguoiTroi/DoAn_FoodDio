﻿namespace BaiTesst
{
    partial class fThucDon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThucDon));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.ucMonAn1 = new BaiTesst.UCMonAn();
            this.ucMonAn2 = new BaiTesst.UCMonAn();
            this.ucMonAn3 = new BaiTesst.UCMonAn();
            this.ucMonAn4 = new BaiTesst.UCMonAn();
            this.ucMonAn5 = new BaiTesst.UCMonAn();
            this.ucMonAn6 = new BaiTesst.UCMonAn();
            this.ucMonAn7 = new BaiTesst.UCMonAn();
            this.ucMonAn8 = new BaiTesst.UCMonAn();
            this.ucMonAn9 = new BaiTesst.UCMonAn();
            this.ucMonAn10 = new BaiTesst.UCMonAn();
            this.ucMonAn11 = new BaiTesst.UCMonAn();
            this.ucMonAn12 = new BaiTesst.UCMonAn();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn1);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn2);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn3);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn4);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn5);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn6);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn7);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn8);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn9);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn10);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn11);
            this.flowLayoutPanel1.Controls.Add(this.ucMonAn12);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // ucMonAn1
            // 
            this.ucMonAn1.GiaMon = "50.000VND";
            this.ucMonAn1.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn1.HinhAnh")));
            this.ucMonAn1.Location = new System.Drawing.Point(3, 3);
            this.ucMonAn1.Name = "ucMonAn1";
            this.ucMonAn1.Size = new System.Drawing.Size(181, 150);
            this.ucMonAn1.TabIndex = 0;
            this.ucMonAn1.TenMon = "Cơm Chiên Dương Châu";
            // 
            // ucMonAn2
            // 
            this.ucMonAn2.GiaMon = "100.000VND";
            this.ucMonAn2.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn2.HinhAnh")));
            this.ucMonAn2.Location = new System.Drawing.Point(190, 3);
            this.ucMonAn2.Name = "ucMonAn2";
            this.ucMonAn2.Size = new System.Drawing.Size(190, 165);
            this.ucMonAn2.TabIndex = 2;
            this.ucMonAn2.TenMon = "Gỏi";
            this.ucMonAn2.Load += new System.EventHandler(this.ucMonAn2_Load);
            // 
            // ucMonAn3
            // 
            this.ucMonAn3.GiaMon = "60.000VND";
            this.ucMonAn3.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn3.HinhAnh")));
            this.ucMonAn3.Location = new System.Drawing.Point(386, 3);
            this.ucMonAn3.Name = "ucMonAn3";
            this.ucMonAn3.Size = new System.Drawing.Size(190, 165);
            this.ucMonAn3.TabIndex = 3;
            this.ucMonAn3.TenMon = "Cơm Chiên Cá Mọi";
            // 
            // ucMonAn4
            // 
            this.ucMonAn4.GiaMon = "50.000VND";
            this.ucMonAn4.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn4.HinhAnh")));
            this.ucMonAn4.Location = new System.Drawing.Point(582, 3);
            this.ucMonAn4.Name = "ucMonAn4";
            this.ucMonAn4.Size = new System.Drawing.Size(190, 165);
            this.ucMonAn4.TabIndex = 4;
            this.ucMonAn4.TenMon = "Phở Bò";
            // 
            // ucMonAn5
            // 
            this.ucMonAn5.GiaMon = "110.000VND";
            this.ucMonAn5.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn5.HinhAnh")));
            this.ucMonAn5.Location = new System.Drawing.Point(3, 174);
            this.ucMonAn5.Name = "ucMonAn5";
            this.ucMonAn5.Size = new System.Drawing.Size(181, 165);
            this.ucMonAn5.TabIndex = 5;
            this.ucMonAn5.TenMon = "Mực Xào";
            // 
            // ucMonAn6
            // 
            this.ucMonAn6.GiaMon = "50.000VND";
            this.ucMonAn6.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn6.HinhAnh")));
            this.ucMonAn6.Location = new System.Drawing.Point(190, 174);
            this.ucMonAn6.Name = "ucMonAn6";
            this.ucMonAn6.Size = new System.Drawing.Size(181, 165);
            this.ucMonAn6.TabIndex = 6;
            this.ucMonAn6.TenMon = "Gỏi Cuốn";
            // 
            // ucMonAn7
            // 
            this.ucMonAn7.GiaMon = "80.000VND";
            this.ucMonAn7.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn7.HinhAnh")));
            this.ucMonAn7.Location = new System.Drawing.Point(377, 174);
            this.ucMonAn7.Name = "ucMonAn7";
            this.ucMonAn7.Size = new System.Drawing.Size(181, 165);
            this.ucMonAn7.TabIndex = 7;
            this.ucMonAn7.TenMon = "Cá Kho";
            // 
            // ucMonAn8
            // 
            this.ucMonAn8.GiaMon = "110.000VND";
            this.ucMonAn8.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn8.HinhAnh")));
            this.ucMonAn8.Location = new System.Drawing.Point(564, 174);
            this.ucMonAn8.Name = "ucMonAn8";
            this.ucMonAn8.Size = new System.Drawing.Size(181, 165);
            this.ucMonAn8.TabIndex = 8;
            this.ucMonAn8.TenMon = "Gà Nướng";
            // 
            // ucMonAn9
            // 
            this.ucMonAn9.GiaMon = "30.000VND";
            this.ucMonAn9.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn9.HinhAnh")));
            this.ucMonAn9.Location = new System.Drawing.Point(3, 345);
            this.ucMonAn9.Name = "ucMonAn9";
            this.ucMonAn9.Size = new System.Drawing.Size(181, 165);
            this.ucMonAn9.TabIndex = 9;
            this.ucMonAn9.TenMon = "Bánh Mì Thịt Nướng";
            // 
            // ucMonAn10
            // 
            this.ucMonAn10.GiaMon = "80.000VND";
            this.ucMonAn10.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn10.HinhAnh")));
            this.ucMonAn10.Location = new System.Drawing.Point(190, 345);
            this.ucMonAn10.Name = "ucMonAn10";
            this.ucMonAn10.Size = new System.Drawing.Size(181, 165);
            this.ucMonAn10.TabIndex = 10;
            this.ucMonAn10.TenMon = "Bò Xào Xả Ớt";
            // 
            // ucMonAn11
            // 
            this.ucMonAn11.GiaMon = "60.000VND";
            this.ucMonAn11.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn11.HinhAnh")));
            this.ucMonAn11.Location = new System.Drawing.Point(377, 345);
            this.ucMonAn11.Name = "ucMonAn11";
            this.ucMonAn11.Size = new System.Drawing.Size(181, 165);
            this.ucMonAn11.TabIndex = 11;
            this.ucMonAn11.TenMon = "Gà Cay";
            // 
            // ucMonAn12
            // 
            this.ucMonAn12.GiaMon = "110.000VND";
            this.ucMonAn12.HinhAnh = ((System.Drawing.Image)(resources.GetObject("ucMonAn12.HinhAnh")));
            this.ucMonAn12.Location = new System.Drawing.Point(564, 345);
            this.ucMonAn12.Name = "ucMonAn12";
            this.ucMonAn12.Size = new System.Drawing.Size(181, 165);
            this.ucMonAn12.TabIndex = 12;
            this.ucMonAn12.TenMon = "Vú Heo Nướng";
            // 
            // fThucDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "fThucDon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thực Đơn";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private UCMonAn ucMonAn1;
        private UCMonAn ucMonAn2;
        private UCMonAn ucMonAn3;
        private UCMonAn ucMonAn4;
        private UCMonAn ucMonAn5;
        private UCMonAn ucMonAn6;
        private UCMonAn ucMonAn7;
        private UCMonAn ucMonAn8;
        private UCMonAn ucMonAn9;
        private UCMonAn ucMonAn10;
        private UCMonAn ucMonAn11;
        private UCMonAn ucMonAn12;
    }
}

